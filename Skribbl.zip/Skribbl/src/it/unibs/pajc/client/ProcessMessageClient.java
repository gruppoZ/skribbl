package it.unibs.pajc.client;

public interface ProcessMessageClient {
	void process(ClientView view, String msg);
}
